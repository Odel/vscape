This client is a basic starting client for people to switch to refactored clients. It is done 100% by Galkon.

==================
Folder Information
==================
There are five folders in the client. Cache, sign, Models, Raw, and Sprites.

Cache: This is where the cache the client uses is located.
sign: Leave this be, it has the location of the cache declared.
Models: This is where you put GZipped models to add to the cache.
Raw: This is where you put RAW .dat models for the client to load.
Sprites: This is where you put sprites to load.

==================
Client Information
==================
This client was built from a blank 317 deob. It requires no server edits to use.
It is built to fit a 503+ gameframe. There are 3 main gameframe pieces, instead of like 12.
The client will most likely NOT work 100% with tutorials out there. I suggest you do my tutorials,
or try doing it yourself.
------------------
Adding models to this client isn't like every other client. You have a choice;

Add models to the cache: Replaces existing models with the ones you pick.
Preloading models: DOES NOT replace any models AND loads models with an ID of up to 50000+.

I suggest using preloading models for new items, because it is much more efficient.
------------------
Interfaces in this client can be made using the traditional code, or Galkon's code.
Galkon's code is shorter, and doesn't make it all as confusing. So wait for a tutorial
on his interfaces to come out by him.
------------------
Adding items in this client can be done the traditional way(with current methods),
or they can be added with my newer methods that are as well shorter. Either way works.
------------------
This client does not have completed orbs by the minimap. They currently display
your current stat text(HP and prayer), and that is all. However, you have been
given the required methods for orb filling/depleting, I'm not going to spoon feed
you guys everything. Plus, there are tutorials you can look at.
------------------
The world map button does not work correctly because some users wish to have it that way.
However, if you want it to work you may do the tutorial released by myself in the
tutorials section.

==================
If you have any questions, please post on the thread. I will help as many people as I can.
Also, please check regularly for new tutorials for my client, as I will release some.

Thanks, and enjoy the client!
--Galkon