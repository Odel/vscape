﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace VEditorSuite
{
    class NpcDefinition
    {
        public int id;
        public string name, examine;
        public int respawn = 0, combat = 0, hitpoints = 1, maxHit = 0, size = 1, attackSpeed = 4000, attackAnim = 422, defenceAnim = 404, deathAnim = 2304, attackBonus = 20, defenceMelee = 20, defenceRange = 20, defenceMage = 20;

        public bool attackable = false;
        public bool aggressive = false;
        public bool retreats = false;
        public bool poisonous = false;

        public static List<NpcDefinition> npcDefs = new List<NpcDefinition>();

        public static NpcDefinition forId(int npcId)
        {
            return npcDefs.FirstOrDefault(def => def.id == npcId);
        }

        public static string NpcDefPathJS = "npcs/npcDefinitions.json";
        public static void LoadDefs()
        {
            npcDefs.Clear();
            try
            {
                using (StreamReader file = File.OpenText(NpcDefPathJS))
                {
                    npcDefs = JsonConvert.DeserializeObject<List<NpcDefinition>>(file.ReadToEnd());
                    file.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to load " + NpcDefPathJS);
            }
        }

        public static void SaveDefs()
        {
            try
            {
                DialogResult result = MessageBox.Show("Do You Want to save to the NpcDefinition file?", "Save NpcDefinitions", MessageBoxButtons.OKCancel);
                if (result.Equals(DialogResult.OK))
                {
                    using (StreamWriter writer = new StreamWriter(NpcDefPathJS))
                    {
                        string json = JsonConvert.SerializeObject(npcDefs, Formatting.Indented);
                        writer.Write(json);
                        writer.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to save " + NpcDefPathJS);
            }
        }
    }
}
