﻿namespace VEditorSuite.Forms
{
    partial class DropEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.reloadDrops = new System.Windows.Forms.ToolStripMenuItem();
            this.saveDrops = new System.Windows.Forms.ToolStripMenuItem();
            this.dropListBox = new System.Windows.Forms.ListBox();
            this.newItemBtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.chanceNumeric = new System.Windows.Forms.NumericUpDown();
            this.quanityListBox = new System.Windows.Forms.ListBox();
            this.removeCountBtn = new System.Windows.Forms.Button();
            this.editCountBtn = new System.Windows.Forms.Button();
            this.newCountBtn = new System.Windows.Forms.Button();
            this.itemListBox = new System.Windows.Forms.ListBox();
            this.removeItemBtn = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chanceNumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reloadDrops,
            this.saveDrops});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(457, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // reloadDrops
            // 
            this.reloadDrops.Name = "reloadDrops";
            this.reloadDrops.Size = new System.Drawing.Size(105, 20);
            this.reloadDrops.Text = "Reload Drop File";
            this.reloadDrops.Click += new System.EventHandler(this.reloadDrops_Click);
            // 
            // saveDrops
            // 
            this.saveDrops.Name = "saveDrops";
            this.saveDrops.Size = new System.Drawing.Size(93, 20);
            this.saveDrops.Text = "Save Drop File";
            this.saveDrops.Click += new System.EventHandler(this.saveDrops_Click);
            // 
            // dropListBox
            // 
            this.dropListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dropListBox.FormattingEnabled = true;
            this.dropListBox.HorizontalScrollbar = true;
            this.dropListBox.Location = new System.Drawing.Point(0, 31);
            this.dropListBox.Name = "dropListBox";
            this.dropListBox.Size = new System.Drawing.Size(167, 368);
            this.dropListBox.TabIndex = 4;
            this.dropListBox.SelectedIndexChanged += new System.EventHandler(this.dropListBox_SelectedIndexChanged);
            // 
            // newItemBtn
            // 
            this.newItemBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.newItemBtn.Image = global::VEditorSuite.Properties.Resources.add;
            this.newItemBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.newItemBtn.Location = new System.Drawing.Point(173, 31);
            this.newItemBtn.Name = "newItemBtn";
            this.newItemBtn.Size = new System.Drawing.Size(77, 23);
            this.newItemBtn.TabIndex = 5;
            this.newItemBtn.Text = "New Item";
            this.newItemBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.newItemBtn.UseVisualStyleBackColor = true;
            this.newItemBtn.Click += new System.EventHandler(this.newItemBtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.chanceNumeric);
            this.panel1.Controls.Add(this.quanityListBox);
            this.panel1.Controls.Add(this.removeCountBtn);
            this.panel1.Controls.Add(this.editCountBtn);
            this.panel1.Controls.Add(this.newCountBtn);
            this.panel1.Controls.Add(this.itemListBox);
            this.panel1.Location = new System.Drawing.Point(167, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(290, 339);
            this.panel1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(197, 279);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "Chance";
            // 
            // chanceNumeric
            // 
            this.chanceNumeric.Location = new System.Drawing.Point(179, 298);
            this.chanceNumeric.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.chanceNumeric.Name = "chanceNumeric";
            this.chanceNumeric.Size = new System.Drawing.Size(103, 20);
            this.chanceNumeric.TabIndex = 6;
            this.chanceNumeric.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.chanceNumeric.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.chanceNumeric.ValueChanged += new System.EventHandler(this.chanceNumeric_ValueChanged);
            // 
            // quanityListBox
            // 
            this.quanityListBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.quanityListBox.FormattingEnabled = true;
            this.quanityListBox.Location = new System.Drawing.Point(169, 0);
            this.quanityListBox.Name = "quanityListBox";
            this.quanityListBox.Size = new System.Drawing.Size(121, 186);
            this.quanityListBox.TabIndex = 1;
            this.quanityListBox.SelectedIndexChanged += new System.EventHandler(this.quanityListBox_SelectedIndexChanged);
            // 
            // removeCountBtn
            // 
            this.removeCountBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.removeCountBtn.Image = global::VEditorSuite.Properties.Resources.delete;
            this.removeCountBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.removeCountBtn.Location = new System.Drawing.Point(172, 246);
            this.removeCountBtn.Name = "removeCountBtn";
            this.removeCountBtn.Size = new System.Drawing.Size(115, 23);
            this.removeCountBtn.TabIndex = 5;
            this.removeCountBtn.Text = "Remove Quanity";
            this.removeCountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.removeCountBtn.UseVisualStyleBackColor = true;
            this.removeCountBtn.Click += new System.EventHandler(this.removeCountBtn_Click);
            // 
            // editCountBtn
            // 
            this.editCountBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.editCountBtn.Image = global::VEditorSuite.Properties.Resources.add;
            this.editCountBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.editCountBtn.Location = new System.Drawing.Point(183, 192);
            this.editCountBtn.Name = "editCountBtn";
            this.editCountBtn.Size = new System.Drawing.Size(95, 23);
            this.editCountBtn.TabIndex = 5;
            this.editCountBtn.Text = "Edit Quanity";
            this.editCountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.editCountBtn.UseVisualStyleBackColor = true;
            this.editCountBtn.Click += new System.EventHandler(this.editCountBtn_Click);
            // 
            // newCountBtn
            // 
            this.newCountBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.newCountBtn.Image = global::VEditorSuite.Properties.Resources.add;
            this.newCountBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.newCountBtn.Location = new System.Drawing.Point(183, 219);
            this.newCountBtn.Name = "newCountBtn";
            this.newCountBtn.Size = new System.Drawing.Size(95, 23);
            this.newCountBtn.TabIndex = 5;
            this.newCountBtn.Text = "New Quanity";
            this.newCountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.newCountBtn.UseVisualStyleBackColor = true;
            this.newCountBtn.Click += new System.EventHandler(this.newCountBtn_Click);
            // 
            // itemListBox
            // 
            this.itemListBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.itemListBox.FormattingEnabled = true;
            this.itemListBox.Location = new System.Drawing.Point(0, 0);
            this.itemListBox.Name = "itemListBox";
            this.itemListBox.Size = new System.Drawing.Size(169, 339);
            this.itemListBox.TabIndex = 0;
            this.itemListBox.SelectedIndexChanged += new System.EventHandler(this.itemListBox_SelectedIndexChanged);
            // 
            // removeItemBtn
            // 
            this.removeItemBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.removeItemBtn.Image = global::VEditorSuite.Properties.Resources.delete;
            this.removeItemBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.removeItemBtn.Location = new System.Drawing.Point(256, 31);
            this.removeItemBtn.Name = "removeItemBtn";
            this.removeItemBtn.Size = new System.Drawing.Size(95, 23);
            this.removeItemBtn.TabIndex = 5;
            this.removeItemBtn.Text = "Remove Item";
            this.removeItemBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.removeItemBtn.UseVisualStyleBackColor = true;
            this.removeItemBtn.Click += new System.EventHandler(this.removeItemBtn_Click);
            // 
            // DropEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(457, 400);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.removeItemBtn);
            this.Controls.Add(this.newItemBtn);
            this.Controls.Add(this.dropListBox);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "DropEditor";
            this.Text = "Drop Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DropEditor_FormClosing);
            this.Load += new System.EventHandler(this.DropEditor_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chanceNumeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem reloadDrops;
        private System.Windows.Forms.ListBox dropListBox;
        private System.Windows.Forms.Button newItemBtn;
        private System.Windows.Forms.ToolStripMenuItem saveDrops;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button removeItemBtn;
        private System.Windows.Forms.ListBox itemListBox;
        private System.Windows.Forms.ListBox quanityListBox;
        private System.Windows.Forms.NumericUpDown chanceNumeric;
        private System.Windows.Forms.Button removeCountBtn;
        private System.Windows.Forms.Button newCountBtn;
        private System.Windows.Forms.Button editCountBtn;
        private System.Windows.Forms.Label label1;
    }
}

