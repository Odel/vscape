﻿namespace VEditorSuite.Forms
{
    partial class EditCountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.confirmBtn = new System.Windows.Forms.Button();
            this.countNumeric = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.countNumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // confirmBtn
            // 
            this.confirmBtn.Location = new System.Drawing.Point(55, 38);
            this.confirmBtn.Name = "confirmBtn";
            this.confirmBtn.Size = new System.Drawing.Size(75, 23);
            this.confirmBtn.TabIndex = 4;
            this.confirmBtn.Text = "Confirm";
            this.confirmBtn.UseVisualStyleBackColor = true;
            this.confirmBtn.Click += new System.EventHandler(this.confirmBtn_Click);
            // 
            // countNumeric
            // 
            this.countNumeric.Location = new System.Drawing.Point(40, 12);
            this.countNumeric.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.countNumeric.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.countNumeric.Name = "countNumeric";
            this.countNumeric.Size = new System.Drawing.Size(120, 20);
            this.countNumeric.TabIndex = 5;
            this.countNumeric.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.countNumeric.ThousandsSeparator = true;
            this.countNumeric.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.countNumeric.ValueChanged += new System.EventHandler(this.countNumeric_ValueChanged);
            // 
            // EditCountForm
            // 
            this.AcceptButton = this.confirmBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(189, 71);
            this.Controls.Add(this.countNumeric);
            this.Controls.Add(this.confirmBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EditCountForm";
            this.Text = "Item Count";
            this.Load += new System.EventHandler(this.EditCountForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.countNumeric)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button confirmBtn;
        private System.Windows.Forms.NumericUpDown countNumeric;
    }
}