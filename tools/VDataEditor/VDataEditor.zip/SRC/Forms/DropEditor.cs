﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Xml;

using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;


namespace VEditorSuite.Forms
{
    public partial class DropEditor : Form
    {
        public int curNpcDrop = 0;
        public int curItem = 0;
        public int curQuanity = 0;

        public List<int> count = new List<int>();

        public List<NpcDropItem> copiedDrops;

        public DropEditor()
        {
            InitializeComponent();
            ItemDefinition.LoadDefs();
            NpcDefinition.LoadDefs();
            NpcDrops.LoadDrops();
            populateDrops();
        }

        private void DropEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            MainForm.dropFormOpen = false;
        }

        public void populateDrops()
        {

            dropListBox.Items.Clear();
            itemListBox.Items.Clear();
            quantityListBox.Items.Clear();

            for (int i = 0; i < NpcDrops.dropList.Count; i++)
            {
                NpcDefinition d = NpcDefinition.forId(NpcDrops.dropList[i].npcId);
                if (d != null)
                {
                    dropListBox.Items.Add(new ListItem() { Value = i, Text = "[" + NpcDrops.dropList[i].npcId + "]" + d.name });
                }
                else
                {
                    dropListBox.Items.Add(new ListItem() { Value = i, Text = "[" + NpcDrops.dropList[i].npcId + "]unknown npc" });
                }
            }
            dropListBox.DisplayMember = "Text";
            populateItems();
            populateQuanity();
            dropListBox.SelectedIndex = curNpcDrop;
        }

        public void populateItems()
        {
            itemListBox.Items.Clear();
            quantityListBox.Items.Clear();
            if (NpcDrops.dropList[curNpcDrop].drops.Count > 0)
            {
                for (int i = 0; i < NpcDrops.dropList[curNpcDrop].drops.Count; i++)
                {
                    string itemName = ItemDefinition.forId(NpcDrops.dropList[curNpcDrop].drops[i].id).name;
                    itemListBox.Items.Add(new ListItem() { Value = NpcDrops.dropList[curNpcDrop].drops[i].id, Text = "[" + NpcDrops.dropList[curNpcDrop].drops[i].id + "]" + itemName });
                }
                itemListBox.DisplayMember = "Text";
                itemListBox.SelectedIndex = 0;
            }
        }

        public void populateQuanity()
        {
            quantityListBox.Items.Clear();
            count.Clear();
            if(NpcDrops.dropList[curNpcDrop].drops.Count > curItem)
            {
                if (NpcDrops.dropList[curNpcDrop].drops[curItem].count.Length > 0)
                {
                    for (int i = 0; i < NpcDrops.dropList[curNpcDrop].drops[curItem].count.Length; i++)
                    {
                        count.Add(NpcDrops.dropList[curNpcDrop].drops[curItem].count[i]);
                        quantityListBox.Items.Add(new ListItem() { Value = NpcDrops.dropList[curNpcDrop].drops[curItem].count[i], Text = "" + NpcDrops.dropList[curNpcDrop].drops[curItem].count[i] });
                    }
                    quantityListBox.DisplayMember = "Text";
                    quantityListBox.SelectedIndex = 0;
                }
            }
        }

        private void dropListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            curNpcDrop = (dropListBox.SelectedItem as ListItem).Value;// dropListBox.SelectedIndex;
            rareTableAccess.Checked = NpcDrops.dropList[curNpcDrop].rareTableAccess;
            populateItems();
        }

        private void itemListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (NpcDrops.dropList[curNpcDrop].drops.Count > 0)
            {
                if (itemListBox.SelectedIndex >= 0)
                {
                    curItem = itemListBox.SelectedIndex;
                }
                else
                {
                    curItem = 0;
                    itemListBox.SelectedIndex = 0;
                }
                chanceNumeric.Value = NpcDrops.dropList[curNpcDrop].drops[curItem].chance;
            }
            populateQuanity();
        }

        private void quanityListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            curQuanity = quantityListBox.SelectedIndex;
        }

        private void newItemBtn_Click(object sender, EventArgs e)
        {
            using (ItemBrowser itemBrowser = new ItemBrowser())
            {
                if (itemBrowser.ShowDialog() == DialogResult.OK)
                {
                    string itemName = ItemDefinition.forId(itemBrowser.itemId).name;
                    count.Add(1);
                    itemListBox.Items.Add(new ListItem() { Value = itemBrowser.itemId, Text = "[" + itemBrowser.itemId + "]" + itemName });
                    quantityListBox.Items.Add(new ListItem() { Value = 1, Text = "1"});
                    NpcDrops.dropList[curNpcDrop].drops.Add(new NpcDropItem(itemBrowser.itemId, new int[] { 1 }, 1));
                    if (NpcDrops.dropList[curNpcDrop].drops[curItem].count.Length > 0)
                    {
                        for (int i = 0; i < NpcDrops.dropList[curNpcDrop].drops[curItem].count.Length; i++)
                        {
                            NpcDrops.dropList[curNpcDrop].drops[curItem].count[i] = count[i];
                        }
                    }
                }
            }
            populateItems();
            populateQuanity();
        }

        private void removeItemBtn_Click(object sender, EventArgs e)
        {
            if (itemListBox.Items.Count > 0)
            {
                NpcDrops.dropList[curNpcDrop].drops.RemoveAt(curItem);
                itemListBox.Items.RemoveAt(curItem);
                populateItems();
                populateQuanity();
            }
        }

        private void newCountBtn_Click(object sender, EventArgs e)
        {
            if (quantityListBox.SelectedIndex >= 0)
            {
                using (EditCountForm editCountForm = new EditCountForm())
                {
                    if (editCountForm.ShowDialog() == DialogResult.OK)
                    {
                        count.Add(editCountForm.count);
                        NpcDrops.dropList[curNpcDrop].drops[curItem].count = count.ToArray();
                    }
                }
                populateItems();
                populateQuanity();
            }
        }

        private void removeCountBtn_Click(object sender, EventArgs e)
        {
            if (quantityListBox.Items.Count > 1 && quantityListBox.SelectedIndex >= 0)
            {
                count.RemoveAt(curQuanity);
                quantityListBox.Items.RemoveAt(curQuanity);
                NpcDrops.dropList[curNpcDrop].drops[curItem].count = count.ToArray();
                populateItems();
                populateQuanity();
            }
        }

        private void editCountBtn_Click(object sender, EventArgs e)
        {
            if (quantityListBox.SelectedIndex >= 0)
            {
                using (EditCountForm editCountForm = new EditCountForm())
                {
                    editCountForm.count = count[curQuanity];
                    if (editCountForm.ShowDialog() == DialogResult.OK)
                    {
                        count[curQuanity] = editCountForm.count;
                        NpcDrops.dropList[curNpcDrop].drops[curItem].count = count.ToArray();
                    }
                }
                populateItems();
                populateQuanity();
            }
        }

        private void chanceNumeric_ValueChanged(object sender, EventArgs e)
        {
            NpcDrops.dropList[curNpcDrop].drops[curItem].chance = (int)chanceNumeric.Value;
        }

        private void DropEditor_Load(object sender, EventArgs e)
        {
        }

        private void reloadDrops_Click(object sender, EventArgs e)
        {
            ItemDefinition.LoadDefs();
            NpcDefinition.LoadDefs();
            NpcDrops.LoadDrops();
            populateDrops();
        }

        private void saveDrops_Click(object sender, EventArgs e)
        {
            NpcDrops.SaveDrops();
        }

        private void copyDrops_Click(object sender, EventArgs e)
        {
            if (NpcDrops.dropList[curNpcDrop].drops != null && NpcDrops.dropList[curNpcDrop].drops.Count > 0)
            {
                copiedDrops  = new List<NpcDropItem>();
                foreach(NpcDropItem drop in NpcDrops.dropList[curNpcDrop].drops)
                {
                    copiedDrops.Add(new NpcDropItem(drop.id, drop.count, drop.chance));
                }
            }
        }

        private void pasteDrops_Click(object sender, EventArgs e)
        {
            if (copiedDrops != null && copiedDrops.Count > 0)
            {
                NpcDrops.dropList[curNpcDrop].drops.Clear();
                for (int i = 0; i < copiedDrops.Count; i++ )
                {
                    NpcDropItem drop = copiedDrops[i];
                    NpcDrops.dropList[curNpcDrop].drops.Add(new NpcDropItem(drop.id, drop.count, drop.chance));
                }
                copiedDrops.Clear();
                copiedDrops = null;
                populateDrops();
            }
        }

        private void rareTableAccess_CheckedChanged(object sender, EventArgs e)
        {
            NpcDrops.dropList[curNpcDrop].rareTableAccess = rareTableAccess.Checked;
        }

        private void filterText_Click(object sender, EventArgs e)
        {
            if (filterText.Text == "filter...")
            {
                filterText.Text = "";
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            if (filterText.Text.Length > 0 && filterText.Text != "filter...")
            {
                filterDrops();
            }
        }

        private void clearSearchBtn_Click(object sender, EventArgs e)
        {
            filterText.Text = "filter...";
            resultCountLabel.Visible = false;
            populateDrops();
        }

        private void filterDrops()
        {
            int searchResultsCount = 0;
            dropListBox.Items.Clear();
            string searchString = filterText.Text;
            for (int i = 0; i < NpcDrops.dropList.Count; i++)
            {
                NpcDefinition d = NpcDefinition.forId(NpcDrops.dropList[i].npcId);
                if (d != null)
                {
                    if (d.name.ToLower().Contains(searchString.ToLower()))
                    {
                        dropListBox.Items.Add(new ListItem() { Value = i, Text = "[" + NpcDrops.dropList[i].npcId + "]" + d.name });
                        searchResultsCount++;
                    }
                }
            }
            dropListBox.DisplayMember = "Text";
            resultCountLabel.Visible = true;
            resultCountLabel.Text = searchResultsCount + " npcs containing " + searchString;
        }

    }
}
