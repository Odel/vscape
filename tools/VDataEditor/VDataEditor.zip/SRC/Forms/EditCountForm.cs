﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VEditorSuite.Forms
{
    public partial class EditCountForm : Form
    {
        public int count = 1;

        public EditCountForm()
        {
            InitializeComponent();

            confirmBtn.DialogResult = DialogResult.OK;
        }

        private void countNumeric_ValueChanged(object sender, EventArgs e)
        {
            count = (int)countNumeric.Value;
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {

        }

        private void EditCountForm_Load(object sender, EventArgs e)
        {
            countNumeric.Value = count;
        }
    }
}
