﻿namespace VEditorSuite.Forms
{
    partial class ItemEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.reloadItemFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveItemFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemListBox = new System.Windows.Forms.ListBox();
            this.resultCountLabel = new System.Windows.Forms.Label();
            this.filterItemsText = new System.Windows.Forms.TextBox();
            this.itemNameLabel = new System.Windows.Forms.Label();
            this.itemDescLabel = new System.Windows.Forms.Label();
            this.specialPriceNumeric = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.generalPriceNumeric = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.storePriceNumeric = new System.Windows.Forms.NumericUpDown();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.itemPicture = new System.Windows.Forms.PictureBox();
            this.clearSearchBtn = new System.Windows.Forms.Button();
            this.searchItemBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.highAlcNumeric = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lowAlcNumeric = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.equipCombo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.abStabNumeric = new System.Windows.Forms.NumericUpDown();
            this.abSlashNumeric = new System.Windows.Forms.NumericUpDown();
            this.abCrushNumeric = new System.Windows.Forms.NumericUpDown();
            this.abMagicNumeric = new System.Windows.Forms.NumericUpDown();
            this.abRangeNumeric = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.strengthNumeric = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dbStabNumeric = new System.Windows.Forms.NumericUpDown();
            this.prayerNumeric = new System.Windows.Forms.NumericUpDown();
            this.dbSlashNumeric = new System.Windows.Forms.NumericUpDown();
            this.dbCrushNumeric = new System.Windows.Forms.NumericUpDown();
            this.dbMagicNumeric = new System.Windows.Forms.NumericUpDown();
            this.dbRangeNumeric = new System.Windows.Forms.NumericUpDown();
            this.untradableCheckBox = new System.Windows.Forms.CheckBox();
            this.stackableCheckBox = new System.Windows.Forms.CheckBox();
            this.twoHandedCheckBox = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.specialPriceNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.generalPriceNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storePriceNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.highAlcNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lowAlcNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.abStabNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.abSlashNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.abCrushNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.abMagicNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.abRangeNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.strengthNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbStabNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prayerNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbSlashNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbCrushNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMagicNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbRangeNumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reloadItemFileToolStripMenuItem,
            this.saveItemFileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(648, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // reloadItemFileToolStripMenuItem
            // 
            this.reloadItemFileToolStripMenuItem.Name = "reloadItemFileToolStripMenuItem";
            this.reloadItemFileToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.reloadItemFileToolStripMenuItem.Text = "Reload Item File";
            this.reloadItemFileToolStripMenuItem.Click += new System.EventHandler(this.reloadItemFileToolStripMenuItem_Click);
            // 
            // saveItemFileToolStripMenuItem
            // 
            this.saveItemFileToolStripMenuItem.Name = "saveItemFileToolStripMenuItem";
            this.saveItemFileToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.saveItemFileToolStripMenuItem.Text = "Save Item File";
            this.saveItemFileToolStripMenuItem.Click += new System.EventHandler(this.saveItemFileToolStripMenuItem_Click);
            // 
            // itemListBox
            // 
            this.itemListBox.FormattingEnabled = true;
            this.itemListBox.Location = new System.Drawing.Point(0, 74);
            this.itemListBox.Name = "itemListBox";
            this.itemListBox.Size = new System.Drawing.Size(196, 277);
            this.itemListBox.TabIndex = 1;
            this.itemListBox.SelectedIndexChanged += new System.EventHandler(this.itemListBox_SelectedIndexChanged);
            // 
            // resultCountLabel
            // 
            this.resultCountLabel.AutoSize = true;
            this.resultCountLabel.Location = new System.Drawing.Point(7, 56);
            this.resultCountLabel.Name = "resultCountLabel";
            this.resultCountLabel.Size = new System.Drawing.Size(101, 13);
            this.resultCountLabel.TabIndex = 9;
            this.resultCountLabel.Text = "x items containing Y";
            this.resultCountLabel.Visible = false;
            // 
            // filterItemsText
            // 
            this.filterItemsText.Location = new System.Drawing.Point(7, 33);
            this.filterItemsText.MaxLength = 60;
            this.filterItemsText.Name = "filterItemsText";
            this.filterItemsText.Size = new System.Drawing.Size(165, 20);
            this.filterItemsText.TabIndex = 6;
            this.filterItemsText.Text = "filter...";
            this.filterItemsText.Click += new System.EventHandler(this.filterItemsText_Click);
            // 
            // itemNameLabel
            // 
            this.itemNameLabel.AutoSize = true;
            this.itemNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemNameLabel.Location = new System.Drawing.Point(260, 33);
            this.itemNameLabel.Name = "itemNameLabel";
            this.itemNameLabel.Size = new System.Drawing.Size(82, 16);
            this.itemNameLabel.TabIndex = 11;
            this.itemNameLabel.Text = "Item Name";
            // 
            // itemDescLabel
            // 
            this.itemDescLabel.AutoSize = true;
            this.itemDescLabel.Location = new System.Drawing.Point(260, 49);
            this.itemDescLabel.Name = "itemDescLabel";
            this.itemDescLabel.Size = new System.Drawing.Size(58, 13);
            this.itemDescLabel.TabIndex = 11;
            this.itemDescLabel.Text = "description";
            // 
            // specialPriceNumeric
            // 
            this.specialPriceNumeric.Location = new System.Drawing.Point(244, 139);
            this.specialPriceNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.specialPriceNumeric.Name = "specialPriceNumeric";
            this.specialPriceNumeric.Size = new System.Drawing.Size(98, 20);
            this.specialPriceNumeric.TabIndex = 13;
            this.specialPriceNumeric.ThousandsSeparator = true;
            this.specialPriceNumeric.ValueChanged += new System.EventHandler(this.specialPriceNumeric_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(203, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "Special Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(203, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "General Store Price";
            // 
            // generalPriceNumeric
            // 
            this.generalPriceNumeric.Location = new System.Drawing.Point(244, 184);
            this.generalPriceNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.generalPriceNumeric.Name = "generalPriceNumeric";
            this.generalPriceNumeric.Size = new System.Drawing.Size(98, 20);
            this.generalPriceNumeric.TabIndex = 13;
            this.generalPriceNumeric.ThousandsSeparator = true;
            this.generalPriceNumeric.ValueChanged += new System.EventHandler(this.generalPriceNumeric_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(203, 208);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Store Price";
            // 
            // storePriceNumeric
            // 
            this.storePriceNumeric.Location = new System.Drawing.Point(244, 230);
            this.storePriceNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.storePriceNumeric.Name = "storePriceNumeric";
            this.storePriceNumeric.Size = new System.Drawing.Size(98, 20);
            this.storePriceNumeric.TabIndex = 13;
            this.storePriceNumeric.ThousandsSeparator = true;
            this.storePriceNumeric.ValueChanged += new System.EventHandler(this.storePriceNumeric_ValueChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::VEditorSuite.Properties.Resources.coins;
            this.pictureBox3.Location = new System.Drawing.Point(206, 226);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 24);
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::VEditorSuite.Properties.Resources.coins;
            this.pictureBox2.Location = new System.Drawing.Point(206, 180);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 24);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::VEditorSuite.Properties.Resources.coins;
            this.pictureBox1.Location = new System.Drawing.Point(206, 135);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 24);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // itemPicture
            // 
            this.itemPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.itemPicture.ErrorImage = null;
            this.itemPicture.ImageLocation = "http://services.runescape.com/m=itemdb_rs/4416_obj_big.gif?id=0";
            this.itemPicture.Location = new System.Drawing.Point(206, 33);
            this.itemPicture.Name = "itemPicture";
            this.itemPicture.Size = new System.Drawing.Size(48, 48);
            this.itemPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.itemPicture.TabIndex = 10;
            this.itemPicture.TabStop = false;
            // 
            // clearSearchBtn
            // 
            this.clearSearchBtn.BackgroundImage = global::VEditorSuite.Properties.Resources.cancel;
            this.clearSearchBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.clearSearchBtn.FlatAppearance.BorderSize = 0;
            this.clearSearchBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearSearchBtn.Location = new System.Drawing.Point(178, 34);
            this.clearSearchBtn.Name = "clearSearchBtn";
            this.clearSearchBtn.Size = new System.Drawing.Size(18, 18);
            this.clearSearchBtn.TabIndex = 7;
            this.clearSearchBtn.UseVisualStyleBackColor = true;
            this.clearSearchBtn.Click += new System.EventHandler(this.clearSearchBtn_Click);
            // 
            // searchItemBtn
            // 
            this.searchItemBtn.BackColor = System.Drawing.Color.Transparent;
            this.searchItemBtn.BackgroundImage = global::VEditorSuite.Properties.Resources.magnifier;
            this.searchItemBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.searchItemBtn.FlatAppearance.BorderSize = 0;
            this.searchItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchItemBtn.Location = new System.Drawing.Point(154, 34);
            this.searchItemBtn.Name = "searchItemBtn";
            this.searchItemBtn.Size = new System.Drawing.Size(18, 18);
            this.searchItemBtn.TabIndex = 8;
            this.searchItemBtn.UseVisualStyleBackColor = false;
            this.searchItemBtn.Click += new System.EventHandler(this.searchItemBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(203, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "High Alchemy";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::VEditorSuite.Properties.Resources.HighAlch;
            this.pictureBox4.Location = new System.Drawing.Point(206, 275);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(32, 24);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // highAlcNumeric
            // 
            this.highAlcNumeric.Location = new System.Drawing.Point(244, 279);
            this.highAlcNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.highAlcNumeric.Name = "highAlcNumeric";
            this.highAlcNumeric.Size = new System.Drawing.Size(98, 20);
            this.highAlcNumeric.TabIndex = 13;
            this.highAlcNumeric.ThousandsSeparator = true;
            this.highAlcNumeric.ValueChanged += new System.EventHandler(this.highAlcNumeric_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(203, 307);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Low Alchemy";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::VEditorSuite.Properties.Resources.LowAlch;
            this.pictureBox5.Location = new System.Drawing.Point(206, 325);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(32, 24);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            // 
            // lowAlcNumeric
            // 
            this.lowAlcNumeric.Location = new System.Drawing.Point(244, 329);
            this.lowAlcNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.lowAlcNumeric.Name = "lowAlcNumeric";
            this.lowAlcNumeric.Size = new System.Drawing.Size(98, 20);
            this.lowAlcNumeric.TabIndex = 13;
            this.lowAlcNumeric.ThousandsSeparator = true;
            this.lowAlcNumeric.ValueChanged += new System.EventHandler(this.lowAlcNumeric_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(410, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Equipment Slot";
            // 
            // equipCombo
            // 
            this.equipCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.equipCombo.FormattingEnabled = true;
            this.equipCombo.Items.AddRange(new object[] {
            "NONE",
            "HAT",
            "CAPE",
            "AMULET",
            "WEAPON",
            "BODY",
            "SHIELD",
            "NULL",
            "LEGS",
            "NULL",
            "GLOVES",
            "BOOTS",
            "NULL",
            "RING",
            "ARROWS"});
            this.equipCombo.Location = new System.Drawing.Point(409, 112);
            this.equipCombo.Name = "equipCombo";
            this.equipCombo.Size = new System.Drawing.Size(121, 21);
            this.equipCombo.TabIndex = 14;
            this.equipCombo.SelectedIndexChanged += new System.EventHandler(this.equipCombo_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(410, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "Attack Bonus";
            // 
            // abStabNumeric
            // 
            this.abStabNumeric.Location = new System.Drawing.Point(413, 168);
            this.abStabNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.abStabNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.abStabNumeric.Name = "abStabNumeric";
            this.abStabNumeric.Size = new System.Drawing.Size(98, 20);
            this.abStabNumeric.TabIndex = 13;
            this.abStabNumeric.ThousandsSeparator = true;
            this.abStabNumeric.ValueChanged += new System.EventHandler(this.abStabNumeric_ValueChanged);
            // 
            // abSlashNumeric
            // 
            this.abSlashNumeric.Location = new System.Drawing.Point(413, 194);
            this.abSlashNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.abSlashNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.abSlashNumeric.Name = "abSlashNumeric";
            this.abSlashNumeric.Size = new System.Drawing.Size(98, 20);
            this.abSlashNumeric.TabIndex = 13;
            this.abSlashNumeric.ThousandsSeparator = true;
            this.abSlashNumeric.ValueChanged += new System.EventHandler(this.abSlashNumeric_ValueChanged);
            // 
            // abCrushNumeric
            // 
            this.abCrushNumeric.Location = new System.Drawing.Point(413, 220);
            this.abCrushNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.abCrushNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.abCrushNumeric.Name = "abCrushNumeric";
            this.abCrushNumeric.Size = new System.Drawing.Size(98, 20);
            this.abCrushNumeric.TabIndex = 13;
            this.abCrushNumeric.ThousandsSeparator = true;
            this.abCrushNumeric.ValueChanged += new System.EventHandler(this.abCrushNumeric_ValueChanged);
            // 
            // abMagicNumeric
            // 
            this.abMagicNumeric.Location = new System.Drawing.Point(413, 246);
            this.abMagicNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.abMagicNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.abMagicNumeric.Name = "abMagicNumeric";
            this.abMagicNumeric.Size = new System.Drawing.Size(98, 20);
            this.abMagicNumeric.TabIndex = 13;
            this.abMagicNumeric.ThousandsSeparator = true;
            this.abMagicNumeric.ValueChanged += new System.EventHandler(this.abMagicNumeric_ValueChanged);
            // 
            // abRangeNumeric
            // 
            this.abRangeNumeric.Location = new System.Drawing.Point(413, 272);
            this.abRangeNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.abRangeNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.abRangeNumeric.Name = "abRangeNumeric";
            this.abRangeNumeric.Size = new System.Drawing.Size(98, 20);
            this.abRangeNumeric.TabIndex = 13;
            this.abRangeNumeric.ThousandsSeparator = true;
            this.abRangeNumeric.ValueChanged += new System.EventHandler(this.abRangeNumeric_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(406, 295);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 16);
            this.label8.TabIndex = 11;
            this.label8.Text = "Strength Bonus";
            // 
            // strengthNumeric
            // 
            this.strengthNumeric.Location = new System.Drawing.Point(413, 314);
            this.strengthNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.strengthNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.strengthNumeric.Name = "strengthNumeric";
            this.strengthNumeric.Size = new System.Drawing.Size(98, 20);
            this.strengthNumeric.TabIndex = 13;
            this.strengthNumeric.ThousandsSeparator = true;
            this.strengthNumeric.ValueChanged += new System.EventHandler(this.strengthNumeric_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(370, 169);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 16);
            this.label9.TabIndex = 11;
            this.label9.Text = "Stab";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(363, 195);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(47, 16);
            this.label10.TabIndex = 11;
            this.label10.Text = "Slash";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(363, 221);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label11.Size = new System.Drawing.Size(47, 16);
            this.label11.TabIndex = 11;
            this.label11.Text = "Crush";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(360, 247);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label12.Size = new System.Drawing.Size(50, 16);
            this.label12.TabIndex = 11;
            this.label12.Text = "Magic";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(356, 273);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(54, 16);
            this.label13.TabIndex = 11;
            this.label13.Text = "Range";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(521, 147);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 16);
            this.label14.TabIndex = 11;
            this.label14.Text = "Defence Bonus";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(526, 296);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(101, 16);
            this.label15.TabIndex = 11;
            this.label15.Text = "Prayer Bonus";
            // 
            // dbStabNumeric
            // 
            this.dbStabNumeric.Location = new System.Drawing.Point(528, 169);
            this.dbStabNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.dbStabNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.dbStabNumeric.Name = "dbStabNumeric";
            this.dbStabNumeric.Size = new System.Drawing.Size(98, 20);
            this.dbStabNumeric.TabIndex = 13;
            this.dbStabNumeric.ThousandsSeparator = true;
            this.dbStabNumeric.ValueChanged += new System.EventHandler(this.dbStabNumeric_ValueChanged);
            // 
            // prayerNumeric
            // 
            this.prayerNumeric.Location = new System.Drawing.Point(528, 315);
            this.prayerNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.prayerNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.prayerNumeric.Name = "prayerNumeric";
            this.prayerNumeric.Size = new System.Drawing.Size(98, 20);
            this.prayerNumeric.TabIndex = 13;
            this.prayerNumeric.ThousandsSeparator = true;
            this.prayerNumeric.ValueChanged += new System.EventHandler(this.prayerNumeric_ValueChanged);
            // 
            // dbSlashNumeric
            // 
            this.dbSlashNumeric.Location = new System.Drawing.Point(528, 195);
            this.dbSlashNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.dbSlashNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.dbSlashNumeric.Name = "dbSlashNumeric";
            this.dbSlashNumeric.Size = new System.Drawing.Size(98, 20);
            this.dbSlashNumeric.TabIndex = 13;
            this.dbSlashNumeric.ThousandsSeparator = true;
            this.dbSlashNumeric.ValueChanged += new System.EventHandler(this.dbSlashNumeric_ValueChanged);
            // 
            // dbCrushNumeric
            // 
            this.dbCrushNumeric.Location = new System.Drawing.Point(528, 221);
            this.dbCrushNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.dbCrushNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.dbCrushNumeric.Name = "dbCrushNumeric";
            this.dbCrushNumeric.Size = new System.Drawing.Size(98, 20);
            this.dbCrushNumeric.TabIndex = 13;
            this.dbCrushNumeric.ThousandsSeparator = true;
            this.dbCrushNumeric.ValueChanged += new System.EventHandler(this.dbCrushNumeric_ValueChanged);
            // 
            // dbMagicNumeric
            // 
            this.dbMagicNumeric.Location = new System.Drawing.Point(528, 247);
            this.dbMagicNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.dbMagicNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.dbMagicNumeric.Name = "dbMagicNumeric";
            this.dbMagicNumeric.Size = new System.Drawing.Size(98, 20);
            this.dbMagicNumeric.TabIndex = 13;
            this.dbMagicNumeric.ThousandsSeparator = true;
            this.dbMagicNumeric.ValueChanged += new System.EventHandler(this.dbMagicNumeric_ValueChanged);
            // 
            // dbRangeNumeric
            // 
            this.dbRangeNumeric.Location = new System.Drawing.Point(528, 273);
            this.dbRangeNumeric.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.dbRangeNumeric.Minimum = new decimal(new int[] {
            2147483647,
            0,
            0,
            -2147483648});
            this.dbRangeNumeric.Name = "dbRangeNumeric";
            this.dbRangeNumeric.Size = new System.Drawing.Size(98, 20);
            this.dbRangeNumeric.TabIndex = 13;
            this.dbRangeNumeric.ThousandsSeparator = true;
            this.dbRangeNumeric.ValueChanged += new System.EventHandler(this.dbRangeNumeric_ValueChanged);
            // 
            // untradableCheckBox
            // 
            this.untradableCheckBox.AutoSize = true;
            this.untradableCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.untradableCheckBox.Location = new System.Drawing.Point(206, 94);
            this.untradableCheckBox.Name = "untradableCheckBox";
            this.untradableCheckBox.Size = new System.Drawing.Size(101, 20);
            this.untradableCheckBox.TabIndex = 15;
            this.untradableCheckBox.Text = "untradable";
            this.untradableCheckBox.UseVisualStyleBackColor = true;
            this.untradableCheckBox.CheckedChanged += new System.EventHandler(this.untradableCheckBox_CheckedChanged);
            // 
            // stackableCheckBox
            // 
            this.stackableCheckBox.AutoSize = true;
            this.stackableCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stackableCheckBox.Location = new System.Drawing.Point(306, 94);
            this.stackableCheckBox.Name = "stackableCheckBox";
            this.stackableCheckBox.Size = new System.Drawing.Size(95, 20);
            this.stackableCheckBox.TabIndex = 15;
            this.stackableCheckBox.Text = "stackable";
            this.stackableCheckBox.UseVisualStyleBackColor = true;
            this.stackableCheckBox.CheckedChanged += new System.EventHandler(this.stackableCheckBox_CheckedChanged);
            // 
            // twoHandedCheckBox
            // 
            this.twoHandedCheckBox.AutoSize = true;
            this.twoHandedCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoHandedCheckBox.Location = new System.Drawing.Point(536, 93);
            this.twoHandedCheckBox.Name = "twoHandedCheckBox";
            this.twoHandedCheckBox.Size = new System.Drawing.Size(105, 20);
            this.twoHandedCheckBox.TabIndex = 15;
            this.twoHandedCheckBox.Text = "twoHanded";
            this.twoHandedCheckBox.UseVisualStyleBackColor = true;
            this.twoHandedCheckBox.CheckedChanged += new System.EventHandler(this.twoHandedCheckBox_CheckedChanged);
            // 
            // ItemEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(648, 356);
            this.Controls.Add(this.twoHandedCheckBox);
            this.Controls.Add(this.stackableCheckBox);
            this.Controls.Add(this.untradableCheckBox);
            this.Controls.Add(this.equipCombo);
            this.Controls.Add(this.lowAlcNumeric);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.highAlcNumeric);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.storePriceNumeric);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.generalPriceNumeric);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dbRangeNumeric);
            this.Controls.Add(this.abRangeNumeric);
            this.Controls.Add(this.dbMagicNumeric);
            this.Controls.Add(this.abMagicNumeric);
            this.Controls.Add(this.dbCrushNumeric);
            this.Controls.Add(this.abCrushNumeric);
            this.Controls.Add(this.dbSlashNumeric);
            this.Controls.Add(this.abSlashNumeric);
            this.Controls.Add(this.prayerNumeric);
            this.Controls.Add(this.strengthNumeric);
            this.Controls.Add(this.dbStabNumeric);
            this.Controls.Add(this.abStabNumeric);
            this.Controls.Add(this.specialPriceNumeric);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.itemDescLabel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.itemNameLabel);
            this.Controls.Add(this.itemPicture);
            this.Controls.Add(this.resultCountLabel);
            this.Controls.Add(this.clearSearchBtn);
            this.Controls.Add(this.searchItemBtn);
            this.Controls.Add(this.filterItemsText);
            this.Controls.Add(this.itemListBox);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ItemEditor";
            this.Text = "Item Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ItemEditor_FormClosing);
            this.Load += new System.EventHandler(this.ItemEditor_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.specialPriceNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.generalPriceNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storePriceNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.highAlcNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lowAlcNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.abStabNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.abSlashNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.abCrushNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.abMagicNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.abRangeNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.strengthNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbStabNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prayerNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbSlashNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbCrushNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMagicNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbRangeNumeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem reloadItemFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveItemFileToolStripMenuItem;
        private System.Windows.Forms.ListBox itemListBox;
        private System.Windows.Forms.Label resultCountLabel;
        private System.Windows.Forms.Button clearSearchBtn;
        private System.Windows.Forms.Button searchItemBtn;
        private System.Windows.Forms.TextBox filterItemsText;
        private System.Windows.Forms.PictureBox itemPicture;
        private System.Windows.Forms.Label itemNameLabel;
        private System.Windows.Forms.Label itemDescLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.NumericUpDown specialPriceNumeric;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.NumericUpDown generalPriceNumeric;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.NumericUpDown storePriceNumeric;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.NumericUpDown highAlcNumeric;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.NumericUpDown lowAlcNumeric;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox equipCombo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown abStabNumeric;
        private System.Windows.Forms.NumericUpDown abSlashNumeric;
        private System.Windows.Forms.NumericUpDown abCrushNumeric;
        private System.Windows.Forms.NumericUpDown abMagicNumeric;
        private System.Windows.Forms.NumericUpDown abRangeNumeric;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown strengthNumeric;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown dbStabNumeric;
        private System.Windows.Forms.NumericUpDown prayerNumeric;
        private System.Windows.Forms.NumericUpDown dbCrushNumeric;
        private System.Windows.Forms.NumericUpDown dbMagicNumeric;
        private System.Windows.Forms.NumericUpDown dbRangeNumeric;
        private System.Windows.Forms.CheckBox untradableCheckBox;
        private System.Windows.Forms.CheckBox stackableCheckBox;
        private System.Windows.Forms.CheckBox twoHandedCheckBox;
        private System.Windows.Forms.NumericUpDown dbSlashNumeric;
    }
}