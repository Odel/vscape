﻿namespace VEditorSuite.Forms
{
    partial class EditShopForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shopNameTextbox = new System.Windows.Forms.TextBox();
            this.tooShortLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.confirmBtn = new System.Windows.Forms.Button();
            this.isGeneralStore = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // shopNameTextbox
            // 
            this.shopNameTextbox.Location = new System.Drawing.Point(12, 25);
            this.shopNameTextbox.MaxLength = 100;
            this.shopNameTextbox.Name = "shopNameTextbox";
            this.shopNameTextbox.Size = new System.Drawing.Size(322, 20);
            this.shopNameTextbox.TabIndex = 0;
            this.shopNameTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.shopNameTextbox.TextChanged += new System.EventHandler(this.shopNameTextbox_TextChanged);
            this.shopNameTextbox.Leave += new System.EventHandler(this.shopNameTextbox_Leave);
            // 
            // tooShortLabel
            // 
            this.tooShortLabel.AutoSize = true;
            this.tooShortLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tooShortLabel.Location = new System.Drawing.Point(109, 48);
            this.tooShortLabel.Name = "tooShortLabel";
            this.tooShortLabel.Size = new System.Drawing.Size(134, 16);
            this.tooShortLabel.TabIndex = 1;
            this.tooShortLabel.Text = "Shop name too short!";
            this.tooShortLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tooShortLabel.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(131, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Shop Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // confirmBtn
            // 
            this.confirmBtn.Enabled = false;
            this.confirmBtn.Location = new System.Drawing.Point(135, 92);
            this.confirmBtn.Name = "confirmBtn";
            this.confirmBtn.Size = new System.Drawing.Size(75, 23);
            this.confirmBtn.TabIndex = 3;
            this.confirmBtn.Text = "Confirm";
            this.confirmBtn.UseVisualStyleBackColor = true;
            this.confirmBtn.Click += new System.EventHandler(this.confirmBtn_Click);
            // 
            // isGeneralStore
            // 
            this.isGeneralStore.AutoSize = true;
            this.isGeneralStore.Location = new System.Drawing.Point(129, 69);
            this.isGeneralStore.Name = "isGeneralStore";
            this.isGeneralStore.Size = new System.Drawing.Size(91, 17);
            this.isGeneralStore.TabIndex = 4;
            this.isGeneralStore.Text = "General Store";
            this.isGeneralStore.UseVisualStyleBackColor = true;
            this.isGeneralStore.CheckedChanged += new System.EventHandler(this.isGeneralStore_CheckedChanged);
            // 
            // EditShopForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(346, 123);
            this.Controls.Add(this.isGeneralStore);
            this.Controls.Add(this.confirmBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tooShortLabel);
            this.Controls.Add(this.shopNameTextbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EditShopForm";
            this.Text = "Edit Shop";
            this.Load += new System.EventHandler(this.EditShopForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox shopNameTextbox;
        private System.Windows.Forms.Label tooShortLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button confirmBtn;
        private System.Windows.Forms.CheckBox isGeneralStore;
    }
}