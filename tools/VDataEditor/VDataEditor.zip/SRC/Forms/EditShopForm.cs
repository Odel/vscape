﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VEditorSuite.Forms
{
    public partial class EditShopForm : Form
    {
        public string shopName = "";
        public bool generalStore = false;
        public int currency = 995;

        public EditShopForm()
        {
            InitializeComponent();

            confirmBtn.DialogResult = DialogResult.OK;
        }

        private void shopNameTextbox_TextChanged(object sender, EventArgs e)
        {
            if (shopNameTextbox.Text.Length > 0)
            {
                confirmBtn.Enabled = true;
                tooShortLabel.Visible = false;
            }
            else
            {
                confirmBtn.Enabled = false;
                tooShortLabel.Visible = true;
            }
            shopName = shopNameTextbox.Text;
        }

        private void shopNameTextbox_Leave(object sender, EventArgs e)
        {
            if (shopNameTextbox.Text.Length > 0)
            {
                confirmBtn.Enabled = true;
                tooShortLabel.Visible = false;
            }
            else
            {
                confirmBtn.Enabled = false;
                tooShortLabel.Visible = true;
            }
            shopName = shopNameTextbox.Text;
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {

        }

        private void isGeneralStore_CheckedChanged(object sender, EventArgs e)
        {
            generalStore = isGeneralStore.Checked;
        }

        private void EditShopForm_Load(object sender, EventArgs e)
        {
            shopNameTextbox.Text = shopName;
            isGeneralStore.Checked = generalStore;
        }
    }
}
