﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VEditorSuite.Forms
{
    public partial class ItemEditor : Form
    {
        public int curItemId = 0;

        public ItemEditor()
        {
            InitializeComponent();
            populateListBox();
        }

        private void populateListBox()
        {
            ItemDefinition.LoadDefs();
            itemListBox.Items.Clear();
            for (int i = 0; i < ItemDefinition.itemDefs.Count; i++)
            {
                itemListBox.Items.Add(new ListItem() { Value = ItemDefinition.itemDefs[i].id, Text = ItemDefinition.itemDefs[i].id + " - " + ItemDefinition.itemDefs[i].name });
            }
            itemListBox.DisplayMember = "Text";
            itemListBox.SelectedIndex = curItemId; 
        }

        private void itemListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            curItemId = (itemListBox.SelectedItem as ListItem).Value;
            editItem();
        }

        private void editItem()
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            itemPicture.ImageLocation = "http://services.runescape.com/m=itemdb_rs/4416_obj_big.gif?id=" + item.id;
            itemNameLabel.Text = "["+item.id+"] "+item.name;
            itemDescLabel.Text = item.examine;
            untradableCheckBox.Checked = item.untradable;
            stackableCheckBox.Checked = item.stackable;
            specialPriceNumeric.Value = item.specialStorePrice;
            generalPriceNumeric.Value = item.generalStorePrice;
            storePriceNumeric.Value = item.shopPrice;
            highAlcNumeric.Value = item.highAlcValue;
            lowAlcNumeric.Value = item.lowAlcValue;
            equipCombo.SelectedItem = item.equipmentType;
            twoHandedCheckBox.Checked = item.twoHanded;
            //bonusboxes
            abStabNumeric.Value = item.bonus[0];
            abSlashNumeric.Value = item.bonus[1];
            abCrushNumeric.Value = item.bonus[2];
            abMagicNumeric.Value = item.bonus[3];
            abRangeNumeric.Value = item.bonus[4];
            dbStabNumeric.Value = item.bonus[5];
            dbSlashNumeric.Value = item.bonus[6];
            dbCrushNumeric.Value = item.bonus[7];
            dbMagicNumeric.Value = item.bonus[8];
            dbRangeNumeric.Value = item.bonus[9];
            strengthNumeric.Value = item.bonus[10];
            prayerNumeric.Value = item.bonus[11];
        }

        private void ItemEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            MainForm.itemFormOpen = false;
        }

        private void reloadItemFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            populateListBox();
        }

        private void saveItemFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ItemDefinition.SaveDefs();
        }

        private void ItemEditor_Load(object sender, EventArgs e)
        {

        }

        private void untradableCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.untradable = untradableCheckBox.Checked;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void stackableCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.stackable = stackableCheckBox.Checked;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void specialPriceNumeric_ValueChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.specialStorePrice = (int)specialPriceNumeric.Value;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void generalPriceNumeric_ValueChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.generalStorePrice = (int)generalPriceNumeric.Value;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void storePriceNumeric_ValueChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.shopPrice = (int)storePriceNumeric.Value;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void highAlcNumeric_ValueChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.highAlcValue = (int)highAlcNumeric.Value;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void lowAlcNumeric_ValueChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.lowAlcValue = (int)lowAlcNumeric.Value;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void equipCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.equipmentType = (string)equipCombo.SelectedItem;
            item.getSlot = equipCombo.SelectedIndex-1;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void twoHandedCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            item.twoHanded = twoHandedCheckBox.Checked;
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void abStabNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(0);
        }

        private void abSlashNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(1);
        }

        private void abCrushNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(2);
        }

        private void abMagicNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(3);
        }

        private void abRangeNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(4);
        }

        private void dbStabNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(5);
        }

        private void dbSlashNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(6);
        }

        private void dbCrushNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(7);
        }

        private void dbMagicNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(8);
        }

        private void dbRangeNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(9);
        }

        private void strengthNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(10);
        }

        private void prayerNumeric_ValueChanged(object sender, EventArgs e)
        {
            changeBonus(11);
        }

        private void changeBonus(int bonusId)
        {
            ItemDefinition item = ItemDefinition.itemDefs[curItemId];
            switch (bonusId)
            {
                case 0:
                    item.bonus[0] = (int)abStabNumeric.Value;
                    break;
                case 1:
                    item.bonus[1] = (int)abSlashNumeric.Value;
                    break;
                case 2:
                    item.bonus[2] = (int)abCrushNumeric.Value;
                    break;
                case 3:
                    item.bonus[3] = (int)abMagicNumeric.Value;
                    break;
                case 4:
                    item.bonus[4] = (int)abRangeNumeric.Value;
                    break;
                case 5:
                    item.bonus[5] = (int)dbStabNumeric.Value;
                    break;
                case 6:
                    item.bonus[6] = (int)dbSlashNumeric.Value;
                    break;
                case 7:
                    item.bonus[7] = (int)dbCrushNumeric.Value;
                    break;
                case 8:
                    item.bonus[8] = (int)dbMagicNumeric.Value;
                    break;
                case 9:
                    item.bonus[9] = (int)dbRangeNumeric.Value;
                    break;
                case 10:
                    item.bonus[10] = (int)strengthNumeric.Value;
                    break;
                case 11:
                    item.bonus[11] = (int)prayerNumeric.Value;
                    break;
            }
            ItemDefinition.itemDefs[curItemId] = item;
        }

        private void filterItemsText_Click(object sender, EventArgs e)
        {
            filterItemsText.Text = "";
        }

        private void searchItemBtn_Click(object sender, EventArgs e)
        {
            if (filterItemsText.Text.Length > 0 && filterItemsText.Text != "filter...")
            {
                filterItems();
            }
        }

        private void clearSearchBtn_Click(object sender, EventArgs e)
        {
            filterItemsText.Text = "filter...";
            resultCountLabel.Visible = false;
            populateListBox();
        }

        private void filterItems()
        {
            int searchResultsCount = 0;
            itemListBox.Items.Clear();
            string searchString = filterItemsText.Text;
            for (int i = 0; i < ItemDefinition.itemDefs.Count; i++)
            {
                if (ItemDefinition.itemDefs[i].name.ToLower().Contains(searchString.ToLower()))
                {
                    itemListBox.Items.Add(new ListItem() { Value = ItemDefinition.itemDefs[i].id, Text = ItemDefinition.itemDefs[i].id + " - " + ItemDefinition.itemDefs[i].name });
                    searchResultsCount++;
                }
                itemListBox.DisplayMember = "Text";
            }
            resultCountLabel.Visible = true;
            resultCountLabel.Text = searchResultsCount + " items containing " + searchString;
        }

        private void filterItemsText_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
