﻿namespace VEditorSuite.Forms
{
    partial class ShopForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shopDataGrid = new System.Windows.Forms.DataGridView();
            this.ItemCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CountCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.reloadShops = new System.Windows.Forms.ToolStripMenuItem();
            this.itemPanel = new System.Windows.Forms.Panel();
            this.shopListBox = new System.Windows.Forms.ListBox();
            this.newShopBtn = new System.Windows.Forms.Button();
            this.removeShopBtn = new System.Windows.Forms.Button();
            this.editShopBtn = new System.Windows.Forms.Button();
            this.newItemBtn = new System.Windows.Forms.Button();
            this.saveShopFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.shopDataGrid)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.itemPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // shopDataGrid
            // 
            this.shopDataGrid.AllowUserToAddRows = false;
            this.shopDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.shopDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCol,
            this.CountCol});
            this.shopDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shopDataGrid.Location = new System.Drawing.Point(0, 0);
            this.shopDataGrid.MultiSelect = false;
            this.shopDataGrid.Name = "shopDataGrid";
            this.shopDataGrid.Size = new System.Drawing.Size(247, 343);
            this.shopDataGrid.TabIndex = 0;
            this.shopDataGrid.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.shopDataGrid_CellMouseDoubleClick);
            this.shopDataGrid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.shopDataGrid_CellValueChanged);
            this.shopDataGrid.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.shopDataGrid_UserAddedRow);
            this.shopDataGrid.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.shopDataGrid_UserDeletedRow);
            this.shopDataGrid.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.shopDataGrid_UserDeletingRow);
            // 
            // ItemCol
            // 
            this.ItemCol.HeaderText = "Item";
            this.ItemCol.MaxInputLength = 10;
            this.ItemCol.Name = "ItemCol";
            this.ItemCol.ReadOnly = true;
            this.ItemCol.ToolTipText = "Item ID";
            // 
            // CountCol
            // 
            this.CountCol.HeaderText = "Count";
            this.CountCol.Name = "CountCol";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reloadShops,
            this.saveShopFileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(457, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // reloadShops
            // 
            this.reloadShops.Name = "reloadShops";
            this.reloadShops.Size = new System.Drawing.Size(106, 20);
            this.reloadShops.Text = "Reload Shop File";
            this.reloadShops.Click += new System.EventHandler(this.reloadShops_Click);
            // 
            // itemPanel
            // 
            this.itemPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.itemPanel.Controls.Add(this.shopDataGrid);
            this.itemPanel.Location = new System.Drawing.Point(210, 57);
            this.itemPanel.Name = "itemPanel";
            this.itemPanel.Size = new System.Drawing.Size(247, 343);
            this.itemPanel.TabIndex = 2;
            // 
            // shopListBox
            // 
            this.shopListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.shopListBox.FormattingEnabled = true;
            this.shopListBox.HorizontalScrollbar = true;
            this.shopListBox.Location = new System.Drawing.Point(0, 31);
            this.shopListBox.Name = "shopListBox";
            this.shopListBox.Size = new System.Drawing.Size(204, 303);
            this.shopListBox.TabIndex = 4;
            this.shopListBox.SelectedIndexChanged += new System.EventHandler(this.shopListBox_SelectedIndexChanged);
            // 
            // newShopBtn
            // 
            this.newShopBtn.Location = new System.Drawing.Point(118, 340);
            this.newShopBtn.Name = "newShopBtn";
            this.newShopBtn.Size = new System.Drawing.Size(75, 23);
            this.newShopBtn.TabIndex = 5;
            this.newShopBtn.Text = "New Shop";
            this.newShopBtn.UseVisualStyleBackColor = true;
            this.newShopBtn.Click += new System.EventHandler(this.newShopBtn_Click);
            // 
            // removeShopBtn
            // 
            this.removeShopBtn.Location = new System.Drawing.Point(56, 369);
            this.removeShopBtn.Name = "removeShopBtn";
            this.removeShopBtn.Size = new System.Drawing.Size(86, 23);
            this.removeShopBtn.TabIndex = 5;
            this.removeShopBtn.Text = "Remove Shop";
            this.removeShopBtn.UseVisualStyleBackColor = true;
            this.removeShopBtn.Click += new System.EventHandler(this.removeShopBtn_Click);
            // 
            // editShopBtn
            // 
            this.editShopBtn.Location = new System.Drawing.Point(12, 340);
            this.editShopBtn.Name = "editShopBtn";
            this.editShopBtn.Size = new System.Drawing.Size(75, 23);
            this.editShopBtn.TabIndex = 5;
            this.editShopBtn.Text = "Edit Shop";
            this.editShopBtn.UseVisualStyleBackColor = true;
            this.editShopBtn.Click += new System.EventHandler(this.editShopBtn_Click);
            // 
            // newItemBtn
            // 
            this.newItemBtn.Location = new System.Drawing.Point(210, 31);
            this.newItemBtn.Name = "newItemBtn";
            this.newItemBtn.Size = new System.Drawing.Size(75, 23);
            this.newItemBtn.TabIndex = 5;
            this.newItemBtn.Text = "New Item";
            this.newItemBtn.UseVisualStyleBackColor = true;
            this.newItemBtn.Click += new System.EventHandler(this.newItemBtn_Click);
            // 
            // saveShopFileToolStripMenuItem
            // 
            this.saveShopFileToolStripMenuItem.Name = "saveShopFileToolStripMenuItem";
            this.saveShopFileToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.saveShopFileToolStripMenuItem.Text = "Save Shop File";
            this.saveShopFileToolStripMenuItem.Click += new System.EventHandler(this.saveShopFileToolStripMenuItem_Click);
            // 
            // ShopForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(457, 400);
            this.Controls.Add(this.removeShopBtn);
            this.Controls.Add(this.editShopBtn);
            this.Controls.Add(this.newItemBtn);
            this.Controls.Add(this.newShopBtn);
            this.Controls.Add(this.shopListBox);
            this.Controls.Add(this.itemPanel);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ShopForm";
            this.Text = "Shop Editor - Bobster - WIP!";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ShopForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.shopDataGrid)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.itemPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView shopDataGrid;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem reloadShops;
        private System.Windows.Forms.Panel itemPanel;
        private System.Windows.Forms.ListBox shopListBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn CountCol;
        private System.Windows.Forms.Button newShopBtn;
        private System.Windows.Forms.Button removeShopBtn;
        private System.Windows.Forms.Button editShopBtn;
        private System.Windows.Forms.Button newItemBtn;
        private System.Windows.Forms.ToolStripMenuItem saveShopFileToolStripMenuItem;
    }
}

