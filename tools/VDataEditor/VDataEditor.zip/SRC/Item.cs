﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VEditorSuite
{
    public class Item
    {
        public int id;
        public int count;

        public Item(int id, int count)
        {
            this.id = id;
            this.count = count;
        }
    }
}
