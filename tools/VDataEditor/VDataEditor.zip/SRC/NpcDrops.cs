﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace VEditorSuite
{
    public class NpcDropItem
    {
        public int id;
        public int[] count;
        public int chance;

        public NpcDropItem(int id, int[] count, int chance)
        {
            this.id = id;
            this.count = count;
            this.chance = chance;
        }
    }

    class NpcDrops
    {
        public int npcId;
        public bool rareTableAccess = false;
        public List<NpcDropItem> drops;

        public static List<NpcDrops> dropList = new List<NpcDrops>();

        public static string DropPathJS = "npcs/npcDrops.json";
        public static void LoadDrops()
        {
            dropList.Clear();
            try
            {
                using (StreamReader file = File.OpenText(DropPathJS))
                {
                    dropList = JsonConvert.DeserializeObject<List<NpcDrops>>(file.ReadToEnd());
                    file.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to load " + DropPathJS);
            }
        }

        public static void SaveDrops()
        {
            try
            {
                DialogResult result = MessageBox.Show("Do You Want to save to the NpcDrops file?", "Save NpcDrops", MessageBoxButtons.OKCancel);
                if (result.Equals(DialogResult.OK))
                {
                    using (StreamWriter writer = new StreamWriter(DropPathJS))
                    {
                        string json = JsonConvert.SerializeObject(dropList, Formatting.Indented);
                        writer.Write(json);
                        writer.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to save " + DropPathJS);
            }
        }
    }
}
