﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using VEditorSuite.Forms;

namespace VEditorSuite
{
    public partial class MainForm : Form
    {
        ShopForm shopForm;
        public static bool shopFormOpen = false;

        ItemEditor itemForm;
        public static bool itemFormOpen = false;

        DropEditor dropForm;
        public static bool dropFormOpen = false;

        public MainForm()
        {
            InitializeComponent();
        }

        private void shopEditorBtn_Click(object sender, EventArgs e)
        {
            if (!shopFormOpen && !itemFormOpen && !dropFormOpen)
            {
                shopForm = new ShopForm();
                shopForm.MdiParent = this;
                shopForm.Show();
                shopFormOpen = true;
            }
        }

        private void itemEditorBtn_Click(object sender, EventArgs e)
        {
            if (!shopFormOpen && !itemFormOpen && !dropFormOpen)
            {
                itemForm = new ItemEditor();
                itemForm.MdiParent = this;
                itemForm.Show();
                itemFormOpen = true;
            }
        }

        private void npcDropButton_Click(object sender, EventArgs e)
        {
            if (!shopFormOpen && !itemFormOpen && !dropFormOpen)
            {
                dropForm = new DropEditor();
                dropForm.MdiParent = this;
                dropForm.Show();
                dropFormOpen = true;
            }
        }
    }
}
