﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace VEditorSuite
{
    public class Shop
    {
        public int shopId;
        public string name;
        public Item[] items;
        public bool isGeneralStore;
        public string currencyType;
        public int currency;

        public static List<Shop> shops = new List<Shop>();

        public static string ShopPathJS = "content/shops.json";
        public static void LoadShops()
        {
            shops.Clear();
            try
            {
                using (StreamReader file = File.OpenText(ShopPathJS))
                {
                    shops = JsonConvert.DeserializeObject<List<Shop>>(file.ReadToEnd());
                    file.Close();
                }
                for (int i = 0; i < shops.Count(); i++)
                {
                    shops[i].shopId = i;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to load " + ShopPathJS);
            }
        }

        public static void SaveShops()
        {
            try
            {
                DialogResult result = MessageBox.Show("Do You Want to save to the Shop file?", "Save Shops", MessageBoxButtons.OKCancel);
                if (result.Equals(DialogResult.OK))
                {
                    using (StreamWriter writer = new StreamWriter(ShopPathJS))
                    {
                        string json = JsonConvert.SerializeObject(shops, Formatting.Indented);
                        writer.Write(json);
                        writer.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to save " + ShopPathJS);
            }
        }
    }
}
