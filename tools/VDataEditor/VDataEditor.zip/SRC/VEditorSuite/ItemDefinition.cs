﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace VEditorSuite
{
    public class ItemDefinition
    {
        public int id;
        public string name;
        public string examine;
        public bool noted;
        public bool noteable;
        public bool stackable;
        public int parentId;
        public int notedId;
        public bool members;
        public int specialStorePrice;
        public int generalStorePrice;
        public int highAlcValue;
        public int lowAlcValue;
        public int[] bonus;
        public String equipmentType;
        public int getSlot;
        public bool twoHanded;
        public int shopPrice;
        public bool untradable;

        public static List<ItemDefinition> itemDefs = new List<ItemDefinition>();

        public static string ItemDefPathJS = "content/itemDefinitions.json";
        public static void LoadDefs()
        {
            itemDefs.Clear();
            try
            {
                using (StreamReader file = File.OpenText(ItemDefPathJS))
                {
                    itemDefs = JsonConvert.DeserializeObject<List<ItemDefinition>>(file.ReadToEnd());
                    file.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to load " + ItemDefPathJS);
            }
        }

        public static void SaveDefs()
        {
            try
            {
                DialogResult result = MessageBox.Show("Do You Want to save to the ItemDefinition file?", "Save ItemDefinitions", MessageBoxButtons.OKCancel);
                if (result.Equals(DialogResult.OK))
                {
                    using (StreamWriter writer = new StreamWriter(ItemDefPathJS))
                    {
                        string json = JsonConvert.SerializeObject(itemDefs, Formatting.Indented);
                        writer.Write(json);
                        writer.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to save " + ItemDefPathJS);
            }
        }
    }
}
