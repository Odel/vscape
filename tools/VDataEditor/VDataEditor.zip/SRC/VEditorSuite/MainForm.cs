﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using VEditorSuite.Forms;

namespace VEditorSuite
{
    public partial class MainForm : Form
    {
        ShopForm shopForm;
        public static bool shopFormOpen = false;

        public MainForm()
        {
            InitializeComponent();
        }

        private void shopEditorBtn_Click(object sender, EventArgs e)
        {
            if (!shopFormOpen)
            {
                Shop.LoadShops();
                shopForm = new ShopForm();
                shopForm.MdiParent = this;
                shopForm.Show();
                shopFormOpen = true;
            }
        }
    }
}
