﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VEditorSuite.Forms
{
    public partial class ItemBrowser : Form
    {
        public int searchResultsCount = 0;

        public ItemBrowser()
        {
            InitializeComponent();
            AcceptButton.DialogResult = DialogResult.OK;

            populateListBox();
        }

        private void populateListBox()
        {
            itemListBox.Items.Clear();
            for (int i = 0; i < ItemDefinition.itemDefs.Count; i++)
            {
                itemListBox.Items.Add(new ListItem() { Value = ItemDefinition.itemDefs[i].id, Text = ItemDefinition.itemDefs[i].id + " - " + ItemDefinition.itemDefs[i].name });
            }
            itemListBox.DisplayMember = "Text";
        }

        private void searchItemText_Click(object sender, EventArgs e)
        {
            searchItemText.Text = "";
        }

        private void searchItemBtn_Click(object sender, EventArgs e)
        {
            if (searchItemText.Text.Length > 0 && searchItemText.Text != "search...")
            {
                searchItemList();
            }
        }

        private void clearSearchBtn_Click(object sender, EventArgs e)
        {
            searchItemText.Text = "search...";
            resultCountLabel.Visible = false;
            populateListBox();
        }

        private void searchItemList()
        {
            searchResultsCount = 0;
            itemListBox.Items.Clear();
            string searchString = searchItemText.Text;
            string[] test = {};
            for (int i = 0; i < ItemDefinition.itemDefs.Count; i++)
            {
                if (ItemDefinition.itemDefs[i].name.ToLower().Contains(searchString.ToLower()))
                {
                    itemListBox.Items.Add(new ListItem() { Value = ItemDefinition.itemDefs[i].id, Text = ItemDefinition.itemDefs[i].id + " - " + ItemDefinition.itemDefs[i].name });
                    searchResultsCount++;
                }
                itemListBox.DisplayMember = "Text";
            }
            resultCountLabel.Visible = true;
            resultCountLabel.Text = searchResultsCount + " items containing " + searchString;
        }

        private void itemListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            itemId = (itemListBox.SelectedItem as ListItem).Value;
        }

        public int itemId;

    }
}
