﻿namespace VEditorSuite.Forms
{
    partial class ItemBrowser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.itemListBox = new System.Windows.Forms.ListBox();
            this.searchItemText = new System.Windows.Forms.TextBox();
            this.confirmBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.clearSearchBtn = new System.Windows.Forms.Button();
            this.searchItemBtn = new System.Windows.Forms.Button();
            this.resultCountLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // itemListBox
            // 
            this.itemListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.itemListBox.FormattingEnabled = true;
            this.itemListBox.Location = new System.Drawing.Point(12, 52);
            this.itemListBox.Name = "itemListBox";
            this.itemListBox.Size = new System.Drawing.Size(198, 212);
            this.itemListBox.TabIndex = 0;
            this.itemListBox.SelectedIndexChanged += new System.EventHandler(this.itemListBox_SelectedIndexChanged);
            // 
            // searchItemText
            // 
            this.searchItemText.Location = new System.Drawing.Point(12, 12);
            this.searchItemText.MaxLength = 60;
            this.searchItemText.Name = "searchItemText";
            this.searchItemText.Size = new System.Drawing.Size(165, 20);
            this.searchItemText.TabIndex = 1;
            this.searchItemText.Text = "search...";
            this.searchItemText.Click += new System.EventHandler(this.searchItemText_Click);
            // 
            // confirmBtn
            // 
            this.confirmBtn.Location = new System.Drawing.Point(12, 270);
            this.confirmBtn.Name = "confirmBtn";
            this.confirmBtn.Size = new System.Drawing.Size(75, 23);
            this.confirmBtn.TabIndex = 3;
            this.confirmBtn.Text = "Confirm";
            this.confirmBtn.UseVisualStyleBackColor = true;
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Location = new System.Drawing.Point(135, 270);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 23);
            this.cancelBtn.TabIndex = 4;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            // 
            // clearSearchBtn
            // 
            this.clearSearchBtn.BackgroundImage = global::VEditorSuite.Properties.Resources.cancel;
            this.clearSearchBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.clearSearchBtn.FlatAppearance.BorderSize = 0;
            this.clearSearchBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearSearchBtn.Location = new System.Drawing.Point(183, 13);
            this.clearSearchBtn.Name = "clearSearchBtn";
            this.clearSearchBtn.Size = new System.Drawing.Size(18, 18);
            this.clearSearchBtn.TabIndex = 2;
            this.clearSearchBtn.UseVisualStyleBackColor = true;
            this.clearSearchBtn.Click += new System.EventHandler(this.clearSearchBtn_Click);
            // 
            // searchItemBtn
            // 
            this.searchItemBtn.BackColor = System.Drawing.Color.Transparent;
            this.searchItemBtn.BackgroundImage = global::VEditorSuite.Properties.Resources.magnifier;
            this.searchItemBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.searchItemBtn.FlatAppearance.BorderSize = 0;
            this.searchItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchItemBtn.Location = new System.Drawing.Point(159, 13);
            this.searchItemBtn.Name = "searchItemBtn";
            this.searchItemBtn.Size = new System.Drawing.Size(18, 18);
            this.searchItemBtn.TabIndex = 2;
            this.searchItemBtn.UseVisualStyleBackColor = false;
            this.searchItemBtn.Click += new System.EventHandler(this.searchItemBtn_Click);
            // 
            // resultCountLabel
            // 
            this.resultCountLabel.AutoSize = true;
            this.resultCountLabel.Location = new System.Drawing.Point(12, 35);
            this.resultCountLabel.Name = "resultCountLabel";
            this.resultCountLabel.Size = new System.Drawing.Size(101, 13);
            this.resultCountLabel.TabIndex = 5;
            this.resultCountLabel.Text = "x items containing Y";
            this.resultCountLabel.Visible = false;
            // 
            // ItemBrowser
            // 
            this.AcceptButton = this.confirmBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(222, 298);
            this.Controls.Add(this.resultCountLabel);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.confirmBtn);
            this.Controls.Add(this.clearSearchBtn);
            this.Controls.Add(this.searchItemBtn);
            this.Controls.Add(this.searchItemText);
            this.Controls.Add(this.itemListBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ItemBrowser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ItemBrowser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox itemListBox;
        private System.Windows.Forms.TextBox searchItemText;
        private System.Windows.Forms.Button searchItemBtn;
        private System.Windows.Forms.Button confirmBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Button clearSearchBtn;
        private System.Windows.Forms.Label resultCountLabel;
    }
}