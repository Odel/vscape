﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Xml;

using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;


namespace VEditorSuite.Forms
{
    public partial class ShopForm : Form
    {
        public int curShop = 0;

        public ShopForm()
        {
            InitializeComponent();
            ItemDefinition.LoadDefs();
            populateShops();
        }

        public void populateShops()
        {
            shopDataGrid.Rows.Clear();
            shopListBox.Items.Clear();

            for (int i = 0; i < Shop.shops.Count; i++)
            {
                shopListBox.Items.Add(Shop.shops[i].name);
            }
            shopListBox.SelectedIndex = curShop; 
        }

        private void shopListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            curShop = shopListBox.SelectedIndex;
            shopDataGrid.Rows.Clear();
            for (int i = 0; i < Shop.shops[curShop].items.Length; i++)
            {
                shopDataGrid.Rows.Add();
                DataGridViewRow R = shopDataGrid.Rows[i];
                R.Cells[0].Value = Shop.shops[curShop].items[i].id;
                R.Cells[1].Value = Shop.shops[curShop].items[i].count;
            }
        }

        private void shopDataGrid_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void shopDataGrid_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {

        }

        private void shopDataGrid_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
        }

        private void shopDataGrid_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewCell cell = shopDataGrid.CurrentCell;

            if (cell.ColumnIndex == 0)
            {
                using (ItemBrowser itemBrowser = new ItemBrowser())
                {
                    DataGridViewRow R = shopDataGrid.Rows[cell.RowIndex];
                    if (R.Cells[0].Value != null)
                    {
                        itemBrowser.itemId = (int)cell.Value;
                    }
                    if (itemBrowser.ShowDialog() == DialogResult.OK)
                    {
                        R.Cells[0].Value = itemBrowser.itemId;
                        if (R.Cells[1].Value == null)
                        {
                            R.Cells[1].Value = 0;
                        }
                        Shop.shops[curShop].items = new Item[shopDataGrid.Rows.Count];
                        for (int i = 0; i < shopDataGrid.Rows.Count; i++)
                        {
                            DataGridViewRow Row = shopDataGrid.Rows[i];
                            int itemId = (int)Row.Cells[0].Value;
                            int itemCount = (int)Row.Cells[1].Value;
                            Shop.shops[curShop].items[i] = new Item(itemId, itemCount);
                        }
                    }
                }
            }
        }

        private void newItemBtn_Click(object sender, EventArgs e)
        {
            using (ItemBrowser itemBrowser = new ItemBrowser())
            {
                shopDataGrid.Rows.Add(1);
                DataGridViewRow R = shopDataGrid.Rows[shopDataGrid.Rows.Count-1];
                if (itemBrowser.ShowDialog() == DialogResult.OK)
                {
                    R.Cells[0].Value = itemBrowser.itemId;
                    if (R.Cells[1].Value == null)
                    {
                        R.Cells[1].Value = 0;
                    }
                    Shop.shops[curShop].items = new Item[shopDataGrid.Rows.Count];
                    for (int i = 0; i < shopDataGrid.Rows.Count; i++)
                    {
                        DataGridViewRow Row = shopDataGrid.Rows[i];
                        int itemId = (int)Row.Cells[0].Value;
                        int itemCount = (int)Row.Cells[1].Value;
                        Shop.shops[curShop].items[i] = new Item(itemId, itemCount);
                    }
                }
            }
        }

        private void ShopForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            MainForm.shopFormOpen = false;
        }

        private void newShopBtn_Click(object sender, EventArgs e)
        {
            using (EditShopForm editShopForm = new EditShopForm())
            {
                editShopForm.Text = "New Shop";
                if (editShopForm.ShowDialog() == DialogResult.OK)
                {
                    NewShop(editShopForm.shopName, editShopForm.generalStore, editShopForm.currency);
                }
            }
        }

        private void removeShopBtn_Click(object sender, EventArgs e)
        {
            Shop.shops.RemoveAt(shopListBox.SelectedIndex);
            for (int i = 0; i < Shop.shops.Count(); i++)
            {
                Shop.shops[i].shopId = i;
            }
            curShop = 0;
            populateShops();
        }

        private void NewShop(string newShopName, bool generalStore, int currency)
        {
            Shop newShop = new Shop();
            newShop.shopId = Shop.shops.Count();
            newShop.name = newShopName;
            newShop.items = new Item[0];
            newShop.isGeneralStore = generalStore;
            newShop.currencyType = "ITEM";
            newShop.currency = currency;
            Shop.shops.Add(newShop);
            curShop = Shop.shops.Count();
            populateShops();
        }

        private void editShopBtn_Click(object sender, EventArgs e)
        {
            using (EditShopForm editShopForm = new EditShopForm())
            {
                editShopForm.shopName = Shop.shops[curShop].name;
                editShopForm.generalStore = Shop.shops[curShop].isGeneralStore;
                editShopForm.currency = Shop.shops[curShop].currency;
                if (editShopForm.ShowDialog() == DialogResult.OK)
                {
                    Shop.shops[curShop].name = editShopForm.shopName;
                    Shop.shops[curShop].isGeneralStore = editShopForm.generalStore;
                    Shop.shops[curShop].currency = editShopForm.currency;
                    populateShops();
                }
            }
        }

        private void reloadShops_Click(object sender, EventArgs e)
        {
            Shop.LoadShops();
            populateShops();
        }

        private void shopDataGrid_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            Shop.shops[curShop].items = new Item[shopDataGrid.Rows.Count];
            for (int i = 0; i < shopDataGrid.Rows.Count; i++)
            {
                DataGridViewRow Row = shopDataGrid.Rows[i];
                int itemId = (int)Row.Cells[0].Value;
                int itemCount = (int)Row.Cells[1].Value;
                Shop.shops[curShop].items[i] = new Item(itemId, itemCount);
            }
        }

        private void saveShopFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Shop.SaveShops();
        }

    }
}
