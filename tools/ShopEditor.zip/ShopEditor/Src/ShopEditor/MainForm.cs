﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Xml;

namespace ShopEditor
{
    public partial class MainForm : Form
    {
        public class Item
        {
            public int id;
            public int count;

            public Item(int id, int count)
            {
                this.id = id;
                this.count = count;
            }
        }

        public class Shop
        {
            public int shopid;
            public string name;
            public Item[] items;
            public bool isGeneralStore;
            public string currencyType;
            public int currency;
        }

        public static Dictionary<int, Shop> shopList = new Dictionary<int, Shop>();

        public static string ItemDefPath = "";
        public static string ShopPath = "shops.xml";

        public int curShop = 0;

        public MainForm()
        {
            InitializeComponent();

            loadShops();

            //shopDataGrid.DataSource = shopList[curShop].item;
        }

        public void loadShops()
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(ShopPath);

            XmlNodeList shops = xmlDoc.GetElementsByTagName("shop");

            for (int i = 0; i < shops.Count; i++)
            {
                Shop newShop = new Shop();
                XmlNodeList shopNode = shops[i].ChildNodes;
                newShop.shopid = int.Parse(shopNode[0].InnerText);
                newShop.name = shopNode[1].InnerText;
                XmlNodeList itemNodeList = shopNode[2].ChildNodes;
                Item[] items = new Item[itemNodeList.Count];
                for (int item = 0; item < itemNodeList.Count; item++)
                {
                    XmlNodeList itemNodes = itemNodeList[item].ChildNodes;
                    int itemId = int.Parse(itemNodes[0].InnerText);
                    int itemCount = int.Parse(itemNodes[1].InnerText);
                    items[item] = new Item(itemId, itemCount);
                }
                newShop.items = items;
                bool.TryParse(shopNode[3].InnerText, out newShop.isGeneralStore);
                newShop.currencyType = shopNode[4].InnerText;
                newShop.currency = int.Parse(shopNode[5].InnerText);
                shopList.Add(i, newShop);

                shopListBox.Items.Add(newShop.name);
            }
            shopListBox.SelectedIndex = 0; 
        }

        private void shopListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            curShop = shopListBox.SelectedIndex;
            shopDataGrid.Rows.Clear();
            for (int i = 0; i < shopList[curShop].items.Length; i++)
            {
                shopDataGrid.Rows.Add();
                DataGridViewRow R = shopDataGrid.Rows[i];
                R.Cells[0].Value = shopList[curShop].items[i].id;
                R.Cells[1].Value = shopList[curShop].items[i].count;
            }
        }

        private void shopDataGrid_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void shopDataGrid_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {

        }

        private void shopDataGrid_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {

        }

    }
}
